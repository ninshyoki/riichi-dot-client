#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
"""Rebuild the pinned CPU runtime within this checkout. No global installation."""
from __future__ import annotations
import argparse,hashlib,json,os,platform,shutil,subprocess,sys,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
COMMIT='0cff2b52982be5b1163aa9a62fb01f03ce91e0d2'
MODEL_COMMIT='524981f21a929e3c3b269f65af79b84163bd02ca'
WEIGHT_SHA='e5f6955b6f19007fd65315e53291b36994493046bc118b991b959e9dc596d660'
RUSTUP_SHA='20a06e644b0d9bd2fbdbfd52d42540bdde820ea7df86e92e533c073da0cdd43c'
RUST_VERSION='1.88.0'

def digest(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def verify_sources(root=ROOT):
    m=json.loads((root/'client/upstream-source-manifest.json').read_text())
    if m['upstream_commit']!=COMMIT or len(m['sources'])!=436:raise RuntimeError('Unexpected upstream source manifest')
    for relative,sha in m['sources'].items():
        path=root/'vendor/Mortal-upstream'/relative
        if path.is_symlink() or not path.resolve().is_relative_to((root/'vendor/Mortal-upstream').resolve()) or not path.is_file() or digest(path)!=sha:
            raise RuntimeError('Upstream source checksum mismatch')
    return m['sources']
def fetch(url,path,sha):
    if path.exists():
        if digest(path)!=sha:raise RuntimeError('Existing file checksum mismatch')
        return
    path.parent.mkdir(parents=True,exist_ok=True);temporary=path.with_name(path.name+'.partial')
    try:
        with urllib.request.urlopen(url,timeout=120) as response,temporary.open('wb') as output:shutil.copyfileobj(response,output)
        if digest(temporary)!=sha:raise RuntimeError('Downloaded file checksum mismatch')
        temporary.replace(path)
    finally:temporary.unlink(missing_ok=True)
def run(args,env=None):subprocess.run([str(a) for a in args],cwd=ROOT,env=env,check=True)
def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--verify-only',action='store_true');args=parser.parse_args()
    sources=verify_sources()
    if args.verify_only:print('Verified all 436 original upstream source files.');return
    if sys.version_info[:2]!=(3,12) or platform.system()!='Linux' or platform.machine()!='x86_64':raise RuntimeError('Wheel lock requires CPython 3.12 on Linux x86_64')
    build=ROOT/'build';build.mkdir(exist_ok=True);python=ROOT/'.venv/bin/python'
    if not python.exists():run([sys.executable,'-m','venv',ROOT/'.venv'])
    run([python,'-m','pip','--isolated','install','--only-binary=:all:','--require-hashes','--index-url','https://pypi.org/simple','--extra-index-url','https://download.pytorch.org/whl/cpu','-r',ROOT/'client/requirements-hashed.lock'])
    run([python,'-m','pip','--isolated','check'])
    weight=ROOT/'assets/Mortal-S42/weights/s42-inference.pth'
    fetch(f'https://huggingface.co/haor/Mortal-S42/resolve/{MODEL_COMMIT}/weights/s42-inference.pth',weight,WEIGHT_SHA)
    if weight.stat().st_size!=43670035:raise RuntimeError('Unexpected checkpoint length')
    installer=build/'downloads/rustup-init'
    fetch('https://static.rust-lang.org/rustup/archive/1.28.2/x86_64-unknown-linux-gnu/rustup-init',installer,RUSTUP_SHA);installer.chmod(0o755)
    home=build/'home';home.mkdir(exist_ok=True)
    env={'PATH':os.defpath,'HOME':str(home),'CARGO_HOME':str(build/'cargo-home'),'RUSTUP_HOME':str(build/'rustup-home'),'CARGO_TARGET_DIR':str(build/'mortal-target'),'PYO3_PYTHON':str(python)}
    # Only dependency acquisition may inherit ordinary platform proxy settings.
    # Never print/save their values. Credential-bearing validation uses proxy=None.
    for key in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY','http_proxy','https_proxy','all_proxy','no_proxy'):
        if key in os.environ:env[key]=os.environ[key]
    cargo=build/'cargo-home/bin/cargo'
    if not cargo.exists():run([installer,'-y','--no-modify-path','--profile','minimal','--default-toolchain',RUST_VERSION],env)
    else:run([build/'cargo-home/bin/rustup','toolchain','install',RUST_VERSION,'--profile','minimal','--no-self-update'],env)
    run([cargo,'+'+RUST_VERSION,'build','--manifest-path',ROOT/'vendor/Mortal-upstream/Cargo.toml','--release','--locked','-p','libriichi','--lib','-j','4'],env)
    suffix=subprocess.check_output([str(python),'-c','import sysconfig;print(sysconfig.get_config_var("EXT_SUFFIX"))'],text=True).strip()
    native=build/'python'/('libriichi'+suffix);native.parent.mkdir(exist_ok=True)
    shutil.copyfile(build/'mortal-target/release/libriichi.so',native);verify_sources()
    manifest={'upstream_commit':COMMIT,'rust':RUST_VERSION,'build_command':'cargo build --release --locked -p libriichi --lib -j 4','sources':sources,'native':{native.relative_to(ROOT).as_posix():digest(native)}}
    (ROOT/'client/runtime-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('Build complete. Run offline tests before user-operated validation.')
if __name__=='__main__':main()
