# SPDX-License-Identifier: AGPL-3.0-or-later
"""Offline loopback transport, real subprocesses and exact server-style replies."""
from __future__ import annotations
import asyncio,json,time
from collections import Counter
from riichienv import RiichiEnv,GameRule
from .worker import InferenceWorker
from .connection import serve_connection
from .offline import latency_summary

class LoopbackSocket:
    def __init__(self):self.incoming=asyncio.Queue();self.replies=asyncio.Queue();self.closed=False
    def put(self,message):self.incoming.put_nowait(json.dumps(message,allow_nan=False))
    async def recv(self):return await self.incoming.get()
    async def send(self,line):await self.replies.put(json.loads(line))
    async def close(self):self.closed=True

def benchmark_opponent(observation):
    # Deterministic legal benchmark opponents only. Never used by live policy.
    actions=observation.legal_actions();pairs=[(a,json.loads(a.to_mjai())) for a in actions]
    for kind in ('hora','none','dahai'):
        found=[a for a,m in pairs if m['type']==kind]
        if found:
            if kind=='dahai':return next((a for a in found if a.tile==observation.drawn_tile),found[0])
            return found[0]
    return actions[0]

async def run_game(*,seed=20261017,threads=1,controlled_seats=(0,1,2,3)):
    workers={};sockets={};tasks={};times=[];counts=[0]*4;outstanding={};request_id=0
    start=time.perf_counter()
    try:
        for seat in controlled_seats:
            workers[seat]=await InferenceWorker.create(threads=threads)
            sockets[seat]=LoopbackSocket();tasks[seat]=asyncio.create_task(serve_connection(sockets[seat],workers[seat]))
            sockets[seat].put({'type':'start_game','id':seat})
        startup=(time.perf_counter()-start)*1000
        env=RiichiEnv(game_mode='4p-red-half',rule=GameRule.default_tenhou(),seed=seed);observations=env.reset()
        while not env.done():
            actions={};started={}
            for seat,obs in observations.items():
                if seat not in workers:actions[seat]=benchmark_opponent(obs);continue
                started[seat]=time.perf_counter();request_id+=3;outstanding[seat]=request_id
                sockets[seat].put({'type':'unknown_information','extra':True})
                sockets[seat].put({'type':'request_action','request_id':request_id,'time':{'grace_ms':3000,'bank_ms':15000,'deadline_ms':18000},'possible_actions':[json.loads(a.to_mjai()) for a in obs.legal_actions()],'observation':obs.serialize_to_base64()})
            for seat,obs in observations.items():
                if seat not in workers:continue
                receive=asyncio.create_task(sockets[seat].replies.get())
                done,_=await asyncio.wait((receive,tasks[seat]),timeout=20,return_when=asyncio.FIRST_COMPLETED)
                if receive not in done:
                    receive.cancel();await asyncio.gather(receive,return_exceptions=True)
                    if tasks[seat].done():await tasks[seat]
                    raise RuntimeError('No process reply before simulated deadline')
                reply=receive.result()
                if reply.get('request_id')!=outstanding[seat]:raise RuntimeError('Stale/future process reply')
                action=obs.select_action_from_mjai(reply)
                if action is None:raise RuntimeError('Illegal process reply')
                actions[seat]=action;counts[seat]+=1;times.append((time.perf_counter()-started[seat])*1000)
                sockets[seat].put({'type':'action_ack','request_id':outstanding[seat],'status':'accepted'})
            observations=env.step(actions)
            if sum(counts)>20000:raise RuntimeError('Process game did not terminate')
        for seat,socket in sockets.items():socket.put({'type':'end_game','scores':env.scores()})
        results=await asyncio.wait_for(asyncio.gather(*tasks.values()),15)
        if not all(result.get('ended') for result in results):raise RuntimeError('Missing game-end result')
        return {'version':'recovery-v2','seed':seed,'threads':threads,'rayon_threads':1,'controlled_seats':list(controlled_seats),'ended':True,'scores':env.scores(),'decisions':sum(counts),'seat_decisions':counts,'illegal_actions':0,'exact_request_ids':True,'startup_ms':startup,'latency':latency_summary(times),'event_counts':dict(Counter(e['type'] for e in env.mjai_log)),'network_included':False,'workers_reaped':[w.process.returncode is not None for w in workers.values()],'transports_closed':[s.closed for s in sockets.values()]}
    finally:
        for task in tasks.values():
            if not task.done():task.cancel()
        await asyncio.gather(*tasks.values(),return_exceptions=True)
        await asyncio.gather(*(w.stop() for w in workers.values()),return_exceptions=True)
        await asyncio.gather(*(s.close() for s in sockets.values()),return_exceptions=True)
