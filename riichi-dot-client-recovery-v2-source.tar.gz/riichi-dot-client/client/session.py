"""Single-game, fail-closed delta-observation session.

Only ``request_action`` invokes the worker. An independent event-loop deadline
invalidates the session and invokes the worker's process-killing ``stop`` even
if cancellation of an inference coroutine alone would not terminate its work.
"""
import asyncio
import math
from copy import deepcopy

from .protocol import ProtocolError, select_legal_reply


class Session:
    def __init__(self, worker, send, *, reserve_ms=250, startup_timeout=10):
        if type(reserve_ms) is not int or reserve_ms < 0:
            raise ValueError('reserve_ms must be a nonnegative integer')
        if type(startup_timeout) not in (int, float) or not math.isfinite(startup_timeout) or startup_timeout <= 0:
            raise ValueError('startup_timeout must be a positive finite number of seconds')
        self.worker = worker
        self.send = send
        self.reserve_ms = reserve_ms
        self.startup_timeout = startup_timeout
        self.seat = None
        self.ready = False
        self.closed = False
        self.ended = False
        self.error = None
        self.closed_event = asyncio.Event()
        self._task = None
        self._startup_task = None
        self._startup_internal_cancels = 0
        self._startup_deadline_handle = None
        self._stop_task = None
        self._deadline_handle = None
        self._seen_start = False
        self._last_request_id = -1

    @staticmethod
    def _integer(value, name):
        if type(value) is not int or value < 0:
            raise ProtocolError(f'{name} must be a nonnegative integer')
        return value

    def _begin_shutdown(self, error=None):
        """Invalidate synchronously, then guarantee one uncancelled worker stop."""
        if error is not None and self.error is None:
            self.error = error
        self.closed = True
        self.ready = False
        self.closed_event.set()
        if self._deadline_handle is not None:
            self._deadline_handle.cancel()
            self._deadline_handle = None
        if self._startup_deadline_handle is not None:
            self._startup_deadline_handle.cancel()
            self._startup_deadline_handle = None
        current = asyncio.current_task()
        for task in (self._task, self._startup_task):
            if task is not None and task is not current and not task.done():
                cancelled = task.cancel()
                if cancelled and task is self._startup_task:
                    self._startup_internal_cancels += 1
        if self._stop_task is None:
            self._stop_task = asyncio.create_task(self._stop_worker())
        return self._stop_task

    async def _stop_worker(self):
        try:
            await self.worker.stop()
        except Exception as exc:
            if self.error is None:
                self.error = exc

    async def _close(self, error=None):
        await asyncio.shield(self._begin_shutdown(error))

    async def handle(self, message):
        """Handle lifecycle events or schedule one answer without blocking receive."""
        received_at = asyncio.get_running_loop().time()
        if self.closed:
            return
        try:
            if not isinstance(message, dict) or type(message.get('type')) is not str:
                raise ProtocolError('message must be an object with a string type')
            kind = message['type']
            if kind == 'start_game':
                await self._start(message)
            elif kind == 'request_action':
                self._request(message, received_at)
            elif kind == 'action_ack':
                self._ack(message)
            elif kind == 'end_game':
                self.ended = True
                await self.stop()
            # Raw MJAI and future informational event types do not drive inference.
        except asyncio.CancelledError:
            if not self.closed:
                await self._close(ProtocolError('session operation cancelled; manual review required'))
            raise
        except Exception as exc:
            await self._close(exc)

    async def _start(self, message):
        if self._seen_start:
            raise ProtocolError('start_game received more than once')
        seat = self._integer(message.get('id'), 'start_game.id')
        if seat > 3:
            raise ProtocolError('start_game.id must be a seat from 0 to 3')
        self._seen_start = True
        self.seat = seat
        self._startup_task = asyncio.current_task()
        startup_task = self._startup_task
        loop = asyncio.get_running_loop()
        deadline = loop.time() + self.startup_timeout
        self._startup_deadline_handle = loop.call_at(deadline, self._startup_expired)
        try:
            await self.worker.start(seat)
            if not self.closed:
                if loop.time() >= deadline:
                    raise TimeoutError('worker seat initialization exceeded startup deadline')
                self.ready = True
        except asyncio.CancelledError:
            if not self.closed:
                raise
            # A shutdown timer or stop() cancelled startup. The independently
            # scheduled stop kills/reaps the process even if start resisted it.
            await asyncio.shield(self._stop_task)
        finally:
            if self._startup_deadline_handle is not None:
                self._startup_deadline_handle.cancel()
                self._startup_deadline_handle = None
            # Consume only our own cancellation requests. Do not leave the
            # receiver task in a cancelling state after a handled timeout.
            while self._startup_internal_cancels:
                startup_task.uncancel()
                self._startup_internal_cancels -= 1
            self._startup_task = None
        if startup_task.cancelling():
            raise asyncio.CancelledError

    def _startup_expired(self):
        if not self.closed and not self.ready:
            self._begin_shutdown(TimeoutError('worker startup timed out; manual review required'))

    def _request(self, message, received_at):
        request_id = self._integer(message.get('request_id'), 'request_id')
        # Ignore repeated deltas before looking at their payload or pending state.
        if request_id <= self._last_request_id:
            return
        if not self.ready:
            raise ProtocolError('request_action before completed start_game')
        if self._task is not None and not self._task.done():
            raise ProtocolError('new request_action while an answer is pending')
        time = message.get('time')
        if not isinstance(time, dict):
            raise ProtocolError('request_action.time must be an object')
        for field in ('grace_ms', 'bank_ms', 'deadline_ms'):
            self._integer(time.get(field), f'time.{field}')
        observation = message.get('observation')
        if type(observation) is not str:
            raise ProtocolError('observation must be a base64 string')
        candidates = message.get('possible_actions')
        if type(candidates) is not list or not candidates:
            raise ProtocolError('possible_actions must be a nonempty list')
        deadline = received_at + (time['deadline_ms'] - self.reserve_ms) / 1000
        if deadline <= asyncio.get_running_loop().time():
            raise TimeoutError('request deadline exhausted by safety reserve')
        self._last_request_id = request_id
        self._task = asyncio.create_task(self._answer(observation, deepcopy(candidates), request_id, deadline))
        self._task.add_done_callback(self._answer_done)
        self._deadline_handle = asyncio.get_running_loop().call_at(deadline, self._expire, request_id)

    def _ack(self, message):
        if 'request_id' in message:
            self._integer(message['request_id'], 'action_ack.request_id')
        if message.get('status') != 'accepted':
            raise ProtocolError('action acknowledgment was not accepted; stop for manual review')

    def _expire(self, request_id):
        if not self.closed and self._last_request_id == request_id:
            self._begin_shutdown(TimeoutError('action deadline expired; manual review required'))

    def _answer_done(self, task):
        # Also catches cancellation before _answer had a chance to enter its body.
        if task.cancelled() and not self.closed:
            self._begin_shutdown(ProtocolError('action cancelled; manual review required'))
        if self._deadline_handle is not None and task is self._task:
            self._deadline_handle.cancel()
            self._deadline_handle = None

    async def _answer(self, observation, candidates, request_id, deadline):
        try:
            if self.closed:
                return
            if asyncio.get_running_loop().time() >= deadline:
                raise TimeoutError('action deadline expired before inference began')
            proposed = await self.worker.act(observation)
            if self.closed or request_id != self._last_request_id:
                return
            if asyncio.get_running_loop().time() >= deadline:
                raise TimeoutError('inference exceeded action deadline')
            reply = select_legal_reply(proposed, candidates, self.seat, request_id)
            if asyncio.get_running_loop().time() >= deadline:
                raise TimeoutError('action deadline expired during legality matching')
            # No await between validity checking and the sole send attempt.
            await self.send(reply)
            if not self.closed and asyncio.get_running_loop().time() >= deadline:
                raise TimeoutError('send exceeded action deadline')
        except asyncio.CancelledError:
            if not self.closed:
                await self._close(ProtocolError('action cancelled; manual review required'))
            raise
        except Exception as exc:
            await self._close(exc)
        finally:
            if self._deadline_handle is not None:
                self._deadline_handle.cancel()
                self._deadline_handle = None

    async def drain(self):
        """Wait for the answer; cancelling this wait permanently invalidates Bot."""
        task = self._task
        if task is None:
            return
        try:
            await asyncio.shield(task)
        except asyncio.CancelledError:
            # A cancelled answer during an intentional stop is already invalid.
            # An externally cancelled drain always records a cancellation error.
            if asyncio.current_task().cancelling():
                await self._close(ProtocolError('drain cancelled; manual review required'))
                raise
            if not self.closed:
                await self._close(ProtocolError('action cancelled; manual review required'))
        if self._stop_task is not None:
            await asyncio.shield(self._stop_task)

    async def stop(self):
        """Permanently close and await worker process termination/reaping."""
        await self._close()
        current = asyncio.current_task()
        tasks = [task for task in (self._task, self._startup_task)
                 if task is not None and task is not current]
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
