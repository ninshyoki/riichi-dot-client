# SPDX-License-Identifier: AGPL-3.0-or-later
"""Recovery-v2 safe S42 loader and original upstream Bot adapter."""
from __future__ import annotations
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import sys
import sysconfig
import re
from .protocol import ProtocolError, select_legal_reply

ROOT=Path(__file__).resolve().parent.parent
CHECKPOINT_SHA256='e5f6955b6f19007fd65315e53291b36994493046bc118b991b959e9dc596d660'
CHECKPOINT_BYTES=43670035
UPSTREAM_COMMIT='0cff2b52982be5b1163aa9a62fb01f03ce91e0d2'

def _digest(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def verify_checkpoint(path):
    path=Path(path)
    if path.stat().st_size!=CHECKPOINT_BYTES or _digest(path)!=CHECKPOINT_SHA256:
        raise ProtocolError('Checkpoint size or SHA-256 differs from pinned S42')
    return path

def validate_state_dict(state,expected):
    import torch
    if not isinstance(state,dict) or set(state)!=set(expected):raise ProtocolError('Unexpected tensor keys')
    for key,value in state.items():
        if not isinstance(value,torch.Tensor) or value.shape!=expected[key].shape or value.dtype!=expected[key].dtype:
            raise ProtocolError('Unexpected tensor shape or dtype')
        if not torch.isfinite(value).all().item():raise ProtocolError('Nonfinite model tensor')

def _import_file(name,path):
    path=Path(path).resolve()
    if name in sys.modules:
        if Path(sys.modules[name].__file__).resolve()!=path:raise ProtocolError('Unexpected preloaded runtime module')
        return sys.modules[name]
    spec=importlib.util.spec_from_file_location(name,path)
    if spec is None or spec.loader is None:raise ProtocolError('Cannot import verified runtime')
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    return module

def verify_runtime(root):
    root=Path(root).resolve()
    pinned=json.loads((root/'client/upstream-source-manifest.json').read_text())
    manifest=json.loads((root/'client/runtime-manifest.json').read_text())
    sources=pinned.get('sources')
    if (pinned.get('upstream_commit')!=UPSTREAM_COMMIT or manifest.get('upstream_commit')!=UPSTREAM_COMMIT
            or not isinstance(sources,dict) or len(sources)!=436 or manifest.get('sources')!=sources):
        raise ProtocolError('Unexpected or incomplete source manifest')
    for relative,digest in sources.items():
        p=PurePosixPath(relative)
        if (p.is_absolute() or '..' in p.parts or p.as_posix()!=relative or '\\' in relative
                or not isinstance(digest,str) or re.fullmatch('[0-9a-f]{64}',digest) is None):
            raise ProtocolError('Unsafe source path or digest')
    expected='build/python/libriichi'+sysconfig.get_config_var('EXT_SUFFIX')
    native_map=manifest.get('native')
    if (not isinstance(native_map,dict) or set(native_map)!={expected}
            or not isinstance(native_map[expected],str) or re.fullmatch('[0-9a-f]{64}',native_map[expected]) is None):
        raise ProtocolError('Unexpected native manifest')
    source=root/'vendor/Mortal-upstream'
    if not source.resolve().is_relative_to(root):raise ProtocolError('Unsafe source path')
    for relative,digest in sources.items():
        path=source/relative
        if not path.resolve().is_relative_to(source.resolve()) or _digest(path)!=digest:
            raise ProtocolError('Upstream source integrity failure')
    native=root/expected
    if not native.resolve().is_relative_to(root/'build/python') or _digest(native)!=native_map[expected]:
        raise ProtocolError('Native runtime integrity failure')
    return source,native

def load_engine(*,threads=1,root=ROOT):
    if type(threads) is not int or threads not in (1,2,4):raise ValueError('CPU threads must be 1, 2, or 4')
    root=Path(root).resolve()
    checkpoint=verify_checkpoint(root/'assets/Mortal-S42/weights/s42-inference.pth')
    source,native=verify_runtime(root)
    _import_file('libriichi',native)
    from libriichi.consts import obs_shape,ACTION_SPACE
    if tuple(obs_shape(4))!=(1012,34) or ACTION_SPACE!=46:raise ProtocolError('Encoder/action-space mismatch')
    import torch
    torch.set_num_threads(threads)
    if torch.get_num_interop_threads()!=1:torch.set_num_interop_threads(1)
    model=_import_file('_s42_upstream_model',source/'mortal/model.py')
    engine=_import_file('_s42_upstream_engine',source/'mortal/engine.py')
    state=torch.load(checkpoint,map_location='cpu',weights_only=True)
    if not isinstance(state,dict) or set(state)!={'mortal','current_dqn'}:raise ProtocolError('Unexpected checkpoint fields')
    brain=model.Brain(version=4,conv_channels=192,num_blocks=40).eval();dqn=model.DQN(version=4).eval()
    validate_state_dict(state['mortal'],brain.state_dict());validate_state_dict(state['current_dqn'],dqn.state_dict())
    brain.load_state_dict(state['mortal'],strict=True);dqn.load_state_dict(state['current_dqn'],strict=True)
    if sum(p.numel() for m in (brain,dqn) for p in m.parameters())!=10835631:raise ProtocolError('Unexpected parameter count')
    result=engine.MortalEngine(brain,dqn,is_oracle=False,version=4,device=torch.device('cpu'),enable_amp=False,enable_quick_eval=False,enable_rule_based_agari_guard=True,name='S42.8k',boltzmann_epsilon=0)
    if not result.enable_rule_based_agari_guard:raise ProtocolError('Original agari guard is unavailable')
    return result

def react_delta(bot,events):
    if not isinstance(events,list) or not events:raise ProtocolError('Empty or invalid MJAI delta')
    raw=None
    for i,event in enumerate(events):
        line=event if isinstance(event,str) else json.dumps(event,allow_nan=False)
        raw=bot.react(line,can_act=(i==len(events)-1))
    if raw is None:raise ProtocolError('No reaction to current MJAI delta')
    result=json.loads(raw)
    if not isinstance(result,dict):raise ProtocolError('Invalid upstream reaction')
    return result

class MortalPolicy:
    def __init__(self,engine,seat):
        if type(seat) is not int or seat not in range(4):raise ProtocolError('Invalid four-player seat')
        from libriichi.mjai import Bot
        self.seat,self.bot=seat,Bot(engine,seat)
    def act(self,observation):
        if observation.player_id!=self.seat:raise ProtocolError('Observation perspective differs from assigned seat')
        proposed=react_delta(self.bot,observation.new_events())
        candidates=[json.loads(a.to_mjai()) for a in observation.legal_actions()]
        select_legal_reply(proposed,candidates,self.seat,0)
        action=observation.select_action_from_mjai(proposed)
        if action is None:raise ProtocolError('Original Mortal output is not legal in observation')
        if proposed['type']=='dahai' and 'tsumogiri' in proposed:
            wanted=proposed['tsumogiri']
            if type(wanted) is not bool or (action.tile==observation.drawn_tile)!=wanted:
                raise ProtocolError('Selected physical tile violates tsumogiri intent')
        return {k:v for k,v in proposed.items() if k!='meta'}
