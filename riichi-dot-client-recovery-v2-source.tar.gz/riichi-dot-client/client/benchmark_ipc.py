# SPDX-License-Identifier: AGPL-3.0-or-later
"""One-worker full-path benchmark; run configurations sequentially without builds."""
import argparse,asyncio,json,os,platform
from pathlib import Path
from .simulate_process import run_game
async def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--threads',type=int,choices=(1,2,4),default=1);p.add_argument('--seed',type=int,default=20261020);p.add_argument('--output',type=Path)
    args=p.parse_args();result=await run_game(seed=args.seed,threads=args.threads,controlled_seats=(0,))
    result['environment']={'logical_cpus':os.cpu_count(),'machine':platform.machine(),'python':platform.python_version(),'contention':'Caller must run after builds and other local inference finish; shared-host scheduling remains uncontrolled.'}
    text=json.dumps(result,indent=2)
    if args.output:args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(text+'\n')
    print(text)
if __name__=='__main__':asyncio.run(main())
