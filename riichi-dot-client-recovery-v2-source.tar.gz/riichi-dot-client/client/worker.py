# SPDX-License-Identifier: AGPL-3.0-or-later
"""One inference process per game, terminated and reaped on cancellation."""
from __future__ import annotations
import argparse
import asyncio
import json
import os
import sys
from .policy import ROOT
from .protocol import ProtocolError
MAX_LINE=4*1024*1024

class InferenceWorker:
    def __init__(self,process):
        self.process=process;self._lock=asyncio.Lock();self._closed=False
    @classmethod
    async def create(cls,*,threads=1):
        env={'PATH':os.defpath,'PYTHONHASHSEED':'0','PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':str(threads),'MKL_NUM_THREADS':str(threads),'OPENBLAS_NUM_THREADS':str(threads),'RAYON_NUM_THREADS':'1'}
        process=await asyncio.create_subprocess_exec(sys.executable,'-m','client.worker','--child','--threads',str(threads),cwd=str(ROOT),env=env,stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.DEVNULL,limit=MAX_LINE)
        worker=cls(process)
        try:
            ready=await asyncio.wait_for(worker._read(),60)
            if ready!={'ready':True}:raise ProtocolError('Inference worker did not warm successfully')
        except BaseException:
            await worker.stop();raise
        return worker
    async def _read(self):
        line=await self.process.stdout.readline()
        if not line or len(line)>MAX_LINE:raise ProtocolError('Inference worker exited or returned an oversized response')
        result=json.loads(line)
        if not isinstance(result,dict) or 'error' in result:raise ProtocolError('Inference worker rejected the request')
        return result
    async def _request(self,payload):
        async with self._lock:
            if self._closed or self.process.returncode is not None:raise ProtocolError('Inference worker is closed')
            try:
                data=(json.dumps(payload,allow_nan=False,separators=(',',':'))+'\n').encode()
                if len(data)>MAX_LINE:raise ProtocolError('Oversized inference request')
                self.process.stdin.write(data);await self.process.stdin.drain()
                return await self._read()
            except BaseException:
                await self.stop();raise
    async def start(self,seat):
        if await self._request({'op':'start','seat':seat})!={'ok':True}:raise ProtocolError('Worker seat initialization failed')
    async def act(self,observation):
        result=await self._request({'op':'act','observation':observation})
        if not isinstance(result.get('action'),dict):raise ProtocolError('Worker returned no action')
        return result['action']
    async def stop(self):
        self._closed=True
        if self.process.returncode is None:
            try:self.process.kill()
            except ProcessLookupError:pass
        await self.process.wait()

def child_main(threads):
    from .policy import load_engine,MortalPolicy
    from riichienv import Observation
    import numpy as np
    engine=load_engine(threads=threads)
    mask=np.zeros(46,dtype=bool);mask[45]=True
    actions,_,_,_=engine.react_batch([np.zeros((1012,34),dtype=np.float32)],[mask],None)
    if actions!=[45]:raise ProtocolError('Warmup failed')
    print(json.dumps({'ready':True}),flush=True);policy=None
    for line in sys.stdin:
        if len(line)>MAX_LINE:raise ProtocolError('Oversized input')
        command=json.loads(line)
        if command.get('op')=='start' and policy is None:
            policy=MortalPolicy(engine,command['seat']);answer={'ok':True}
        elif command.get('op')=='act' and policy is not None:
            encoded=command['observation']
            if not isinstance(encoded,str) or len(encoded)>MAX_LINE//2:raise ProtocolError('Invalid observation')
            obs=Observation.deserialize_from_base64(encoded);answer={'action':policy.act(obs)}
        else:raise ProtocolError('Invalid worker lifecycle')
        print(json.dumps(answer,allow_nan=False,separators=(',',':')),flush=True)

def main():
    parser=argparse.ArgumentParser(description='Internal inference worker; no network or credentials')
    parser.add_argument('--child',action='store_true',required=True);parser.add_argument('--threads',type=int,choices=(1,2,4),default=1)
    args=parser.parse_args()
    try:child_main(args.threads)
    except Exception:
        print(json.dumps({'error':'inference_failed'}),flush=True);raise SystemExit(1)
if __name__=='__main__':main()
