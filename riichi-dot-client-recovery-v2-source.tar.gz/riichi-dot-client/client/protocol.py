"""Validate native decisions against literal server-provided legal actions.

No fallback action is chosen here. A decision must identify exactly one literal
legal candidate, including red-five identity and consumed-tile multiplicity.
"""
from collections import Counter
from copy import deepcopy


class ProtocolError(Exception):
    """An unsafe or unsupported protocol message or decision."""


_ACTIONS = frozenset({'dahai', 'chi', 'pon', 'daiminkan', 'ankan', 'kakan',
                      'reach', 'hora', 'ryukyoku', 'none'})
_TILES = frozenset({f'{number}{suit}' for suit in 'mps' for number in range(1, 10)}
                   | {'5mr', '5pr', '5sr', 'E', 'S', 'W', 'N', 'P', 'F', 'C'})
_CONSUMED = {'chi': 2, 'pon': 2, 'daiminkan': 3, 'kakan': 3, 'ankan': 4}
_REQUIRES_PAI = frozenset({'dahai', 'chi', 'pon', 'daiminkan', 'kakan'})


def _seat(value, field):
    if type(value) is not int or not 0 <= value < 4:
        raise ProtocolError(f'{field} must be an integer seat from 0 to 3')


def _tile(value):
    if type(value) is not str or value not in _TILES:
        raise ProtocolError('invalid MJAI tile')


def _validate_action(action, seat):
    if not isinstance(action, dict):
        raise ProtocolError('action must be an object')
    kind = action.get('type')
    if type(kind) is not str or kind not in _ACTIONS:
        raise ProtocolError('unknown action type')
    for field in ('actor', 'target'):
        if field in action:
            _seat(action[field], field)
    if 'actor' in action and action['actor'] != seat:
        raise ProtocolError('action actor differs from assigned seat')
    if 'tsumogiri' in action and type(action['tsumogiri']) is not bool:
        raise ProtocolError('tsumogiri must be a boolean')
    if kind in _REQUIRES_PAI and 'pai' not in action:
        raise ProtocolError('action is missing pai')
    if 'pai' in action:
        _tile(action['pai'])
    if kind in _CONSUMED:
        consumed = action.get('consumed')
        if type(consumed) is not list or len(consumed) != _CONSUMED[kind]:
            raise ProtocolError('incorrect consumed-tile count')
    if 'consumed' in action:
        if type(action['consumed']) is not list:
            raise ProtocolError('consumed must be a list')
        for tile in action['consumed']:
            _tile(tile)


def _matches(proposed, candidate):
    if proposed['type'] != candidate['type']:
        return False
    for field in ('pai', 'target', 'tsumogiri'):
        if field in proposed and field in candidate and proposed[field] != candidate[field]:
            return False
    if 'consumed' in proposed and 'consumed' in candidate:
        if Counter(proposed['consumed']) != Counter(candidate['consumed']):
            return False
    return True


def _literal_equal(left, right):
    """Type-aware equality: unknown metadata True and 1 are distinct literals."""
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(_literal_equal(left[k], right[k]) for k in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(_literal_equal(a, b) for a, b in zip(left, right))
    return left == right


def select_legal_reply(proposed: dict, candidates: list[dict], seat: int, request_id: int) -> dict:
    """Return a deep copy of the unique matching server candidate with its ID.

    Optional server fields remain absent. Actor is supplied only when needed;
    ``none`` keeps the server's actor omission. Unknown candidate fields survive.
    """
    _seat(seat, 'seat')
    if type(request_id) is not int or request_id < 0:
        raise ProtocolError('request_id must be a nonnegative integer')
    _validate_action(proposed, seat)
    if type(candidates) is not list:
        raise ProtocolError('possible_actions must be a list')
    matches = []
    for candidate in candidates:
        _validate_action(candidate, seat)
        if _matches(proposed, candidate) and not any(_literal_equal(candidate, prior) for prior in matches):
            matches.append(candidate)
    if len(matches) != 1:
        raise ProtocolError('no unique literal legal action matches the native decision')
    reply = deepcopy(matches[0])
    if reply['type'] != 'none' and 'actor' not in reply:
        reply['actor'] = seat
    reply['request_id'] = request_id
    return reply
