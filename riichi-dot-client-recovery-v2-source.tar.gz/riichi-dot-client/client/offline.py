# SPDX-License-Identifier: AGPL-3.0-or-later
"""Complete offline four-seat Mortal hanchans; no network or credentials."""
from __future__ import annotations
import argparse,json,time
from collections import Counter
from pathlib import Path
import numpy as np
from riichienv import RiichiEnv,GameRule,Observation
from .policy import load_engine,MortalPolicy
from .protocol import select_legal_reply

def latency_summary(samples):
    a=np.asarray(samples,dtype=float)
    return {'samples':len(samples),'p50_ms':float(np.percentile(a,50)),'p95_ms':float(np.percentile(a,95)),'p99_ms':float(np.percentile(a,99)),'max_ms':float(a.max())} if len(a) else {'samples':0}

def run_game(*,seed=20261016,threads=1):
    cold=time.perf_counter();engine=load_engine(threads=threads)
    startup=(time.perf_counter()-cold)*1000
    policies={seat:MortalPolicy(engine,seat) for seat in range(4)}
    env=RiichiEnv(game_mode='4p-red-half',rule=GameRule.default_tenhou(),seed=seed)
    observations=env.reset();times=[];counts=[0]*4;request_id=0
    while not env.done():
        actions={}
        for seat,observation in observations.items():
            start=time.perf_counter();encoded=observation.serialize_to_base64();decoded=Observation.deserialize_from_base64(encoded)
            proposed=policies[seat].act(decoded)
            candidates=[json.loads(action.to_mjai()) for action in observation.legal_actions()]
            request_id+=3;reply=select_legal_reply(proposed,candidates,seat,request_id)
            reply=json.loads(json.dumps(reply,allow_nan=False))
            if reply['request_id']!=request_id:raise RuntimeError('Request ID mismatch')
            action=observation.select_action_from_mjai(reply)
            if action is None:raise RuntimeError('Illegal offline reply')
            actions[seat]=action;counts[seat]+=1;times.append((time.perf_counter()-start)*1000)
        observations=env.step(actions)
        if sum(counts)>20000:raise RuntimeError('Offline game did not terminate')
    return {'version':'recovery-v2','seed':seed,'threads':threads,'ended':env.done(),'scores':env.scores(),'ranks':env.ranks(),'decisions':sum(counts),'seat_decisions':counts,'illegal_actions':0,'startup_ms':startup,'latency':latency_summary(times),'event_counts':dict(Counter(e['type'] for e in env.mjai_log)),'network_included':False}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--threads',type=int,choices=(1,2,4),default=1);p.add_argument('--games',type=int,default=1);p.add_argument('--seed',type=int,default=20261016);p.add_argument('--output',type=Path)
    a=p.parse_args()
    if not 1<=a.games<=100:raise ValueError('games must be 1..100')
    results=[run_game(seed=a.seed+i,threads=a.threads) for i in range(a.games)]
    text=json.dumps({'version':'recovery-v2','games':results},indent=2)
    if a.output:a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(text+'\n')
    print(text)
if __name__=='__main__':main()
