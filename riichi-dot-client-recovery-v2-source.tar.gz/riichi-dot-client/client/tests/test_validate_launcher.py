import asyncio,getpass,io,os,ssl,sys,tempfile,unittest,warnings
from pathlib import Path
from unittest.mock import patch,AsyncMock
from client.tests.fakes import Worker,Socket

class LauncherTests(unittest.TestCase):
    def test_noninteractive_fails_before_prompt(self):
        from client import validate_one as launch
        with patch.object(sys.stdin,'isatty',return_value=False),patch.object(getpass,'getpass') as prompt:
            with self.assertRaises(RuntimeError):launch.read_token()
            prompt.assert_not_called()
    def test_echo_fallback_is_forbidden(self):
        from client import validate_one as launch
        def fallback(**kw):warnings.warn('synthetic',getpass.GetPassWarning);return 'synthetic-token'
        with patch.object(launch,'require_tty'),patch.object(getpass,'getpass',side_effect=fallback):
            with self.assertRaises(getpass.GetPassWarning):launch.read_token()
    def test_empty_entry_cancels(self):
        from client import validate_one as launch
        with patch.object(launch,'require_tty'),patch.object(getpass,'getpass',return_value=''):self.assertIsNone(launch.read_token())
    def test_malformed_token_has_generic_error(self):
        from client import validate_one as launch
        for value in ('with space','line\nbreak','\x00','x'*16385):
            with self.subTest(value_length=len(value)),patch.object(launch,'require_tty'),patch.object(getpass,'getpass',return_value=value):
                with self.assertRaisesRegex(RuntimeError,'^Invalid token input$'):launch.read_token()
    def test_tls_key_logging_override_is_ignored(self):
        from client import validate_one as launch
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'must-not-exist.keys'
            with patch.dict(os.environ,{'SSLKEYLOGFILE':str(p)}):context=launch.make_ssl_context()
            self.assertIsNone(context.keylog_filename);self.assertFalse(p.exists())
            self.assertTrue(context.check_hostname);self.assertEqual(context.verify_mode,ssl.CERT_REQUIRED)
    def test_redirect_is_never_followed(self):
        from client import validate_one as launch
        connector=launch.NoRedirectConnect(launch.ENDPOINT,proxy=None);error=RuntimeError('redirect')
        self.assertIs(connector.process_redirect(error),error)
    def test_argv_rejected_without_echoing_arguments(self):
        from client import validate_one as launch
        with patch.object(sys,'argv',['launcher','synthetic-secret']),patch('sys.stderr',new_callable=io.StringIO) as out:
            self.assertEqual(launch.main(),2);self.assertNotIn('synthetic-secret',out.getvalue())

class AsyncLauncherTests(unittest.IsolatedAsyncioTestCase):
    async def test_user_submission_only_once_at_fixed_endpoint(self):
        from client import validate_one as launch
        order=[];worker=Worker();socket=Socket();outer=self
        async def create(**kw):order.append('warm');outer.assertEqual(kw,{'threads':1});return worker
        def token():order.append('user_enter');return 'synthetic-token'
        class Connect:
            def __init__(self,uri,**kw):
                order.append('connect');outer.assertEqual(uri,'wss://game.riichi.dev/ws/validate')
                outer.assertEqual(kw['additional_headers'],{'Authorization':'Bearer synthetic-token'})
                outer.assertIsNone(kw['proxy']);outer.assertTrue(kw['logger'].disabled)
                outer.assertTrue(kw['ssl'].check_hostname)
            async def __aenter__(self):return socket
            async def __aexit__(self,*a):await socket.close()
        with patch.object(launch.InferenceWorker,'create',side_effect=create),patch.object(launch,'read_token',side_effect=token),patch.object(launch,'connect',Connect),patch.object(launch,'serve_connection',new=AsyncMock(return_value={'validation_passed':True})),patch('sys.stdout',new_callable=io.StringIO) as out:
            self.assertEqual(await launch.run(),0);self.assertNotIn('synthetic-token',out.getvalue())
        self.assertEqual(order,['warm','user_enter','connect']);self.assertTrue(worker.stopped)
    async def test_exception_header_never_logged_or_retried(self):
        from client import validate_one as launch
        worker=Worker()
        with patch.object(launch.InferenceWorker,'create',new=AsyncMock(return_value=worker)),patch.object(launch,'read_token',return_value='synthetic-token'),patch.object(launch,'connect',side_effect=RuntimeError('Bearer synthetic-token')) as connect,patch('sys.stdout',new_callable=io.StringIO) as out:
            self.assertEqual(await launch.run(),1);self.assertNotIn('synthetic-token',out.getvalue());self.assertEqual(connect.call_count,1)
        self.assertTrue(worker.stopped)
    async def test_warmup_failure_never_prompts_or_connects(self):
        from client import validate_one as launch
        with patch.object(launch.InferenceWorker,'create',new=AsyncMock(side_effect=RuntimeError())),patch.object(launch,'read_token') as prompt,patch.object(launch,'connect') as connect,patch('sys.stdout',new_callable=io.StringIO):
            self.assertEqual(await launch.run(),1);prompt.assert_not_called();connect.assert_not_called()
