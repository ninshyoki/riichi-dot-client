"""Native original Bot rare-action fixtures; not full server-wire integration."""
import json
import numpy as np
import pytest
from client.policy import load_engine,react_delta
from client.protocol import select_legal_reply
@pytest.fixture(scope='module',autouse=True)
def runtime():return load_engine(threads=1)
class PreferAction:
    engine_type='mortal';name='native-fixture-only';is_oracle=False;version=4;enable_quick_eval=False;enable_rule_based_agari_guard=True
    def __init__(self,index):self.index=index;self.masks=[]
    def react_batch(self,obs,masks,invisible_obs):
        m=np.asarray(masks);self.masks.extend(m.tolist());q=np.where(m,0.,-np.inf)
        q[:,self.index]=np.where(m[:,self.index],100.,-np.inf)
        return q.argmax(-1).tolist(),q.tolist(),m.tolist(),[True]*len(m)
def beginning(seat,hand):
    hands=[['?']*13 for _ in range(4)];hands[seat]=hand
    return [{'type':'start_game'},{'type':'start_kyoku','bakaze':'E','kyoku':1,'honba':0,'kyotaku':0,'oya':seat,'scores':[25000]*4,'dora_marker':'9p','tehais':hands}]
def check_native(seat,events,result):
    from libriichi.state import PlayerState
    state=PlayerState(seat)
    for event in events:state.update(json.dumps(event))
    state.validate_reaction(json.dumps(result))
    candidate={k:v for k,v in result.items() if k not in ('meta','target','tsumogiri','actor')}
    wire=select_legal_reply(result,[candidate],seat,71)
    assert wire['request_id']==71
    assert 'target' not in wire and 'tsumogiri' not in wire
    return state
EXTRAS=['1p','2p','3p','4p','6p','7p','8p','1s','2s','3s','E']
@pytest.mark.parametrize('seat',range(4))
@pytest.mark.parametrize('kind,index,first,discard',[
 ('chi',38,['5mr','6m'],'4m'),('pon',41,['5mr','5m'],'5m'),
 ('daiminkan',42,['5mr','5m','5m'],'5m'),('ankan',42,['5mr','5m','5m'],'5m')])
def test_red_calls_and_kans_native(seat,kind,index,first,discard):
    from libriichi.mjai import Bot
    hand=first+EXTRAS[:13-len(first)];events=beginning(seat,hand)
    if kind=='ankan':events.append({'type':'tsumo','actor':seat,'pai':discard})
    else:
        target=(seat-1)%4
        events.extend([{'type':'tsumo','actor':target,'pai':'?'},{'type':'dahai','actor':target,'pai':discard,'tsumogiri':True}])
    result=react_delta(Bot(PreferAction(index),seat),events)
    assert result['type']==kind and result['actor']==seat and '5mr' in result['consumed']
    check_native(seat,events,result)
@pytest.mark.parametrize('seat',range(4))
def test_native_pon_then_kakan(seat):
    from libriichi.mjai import Bot
    engine=PreferAction(41);bot=Bot(engine,seat);target=(seat-1)%4
    events=beginning(seat,['5mr','5m']+EXTRAS)
    events.extend([{'type':'tsumo','actor':target,'pai':'?'},{'type':'dahai','actor':target,'pai':'5m','tsumogiri':True}])
    pon=react_delta(bot,events);assert pon['type']=='pon';pon.pop('meta',None)
    delta=[pon,{'type':'dahai','actor':seat,'pai':'E','tsumogiri':False}]
    for offset in (1,2,3):delta.extend([{'type':'tsumo','actor':(seat+offset)%4,'pai':'?'},{'type':'dahai','actor':(seat+offset)%4,'pai':'9s','tsumogiri':True}])
    delta.append({'type':'tsumo','actor':seat,'pai':'5m'});engine.index=42
    result=react_delta(bot,delta)
    assert result['type']=='kakan' and result['pai']=='5m' and '5mr' in result['consumed']
    check_native(seat,events+delta,result)
@pytest.mark.parametrize('seat',range(4))
def test_declined_riichi_ron_remains_furiten_after_own_draw(seat):
    from libriichi.mjai import Bot
    hand=['2m','3m','4m','5mr','6m','4p','5p','6p','7p','8p','9p','5s','8s']
    target=(seat+1)%4;events=beginning(seat,hand)
    events.extend([{'type':'tsumo','actor':seat,'pai':'8s'},{'type':'reach','actor':seat},{'type':'dahai','actor':seat,'pai':'5s','tsumogiri':False},{'type':'reach_accepted','actor':seat},{'type':'tsumo','actor':target,'pai':'?'},{'type':'dahai','actor':target,'pai':'1m','tsumogiri':True}])
    engine=PreferAction(45);bot=Bot(engine,seat)
    result=react_delta(bot,events);assert result['type']=='none' and engine.masks[-1][43]
    delta=[]
    for offset,tile in ((2,'9s'),(3,'9p')):delta.extend([{'type':'tsumo','actor':(seat+offset)%4,'pai':'?'},{'type':'dahai','actor':(seat+offset)%4,'pai':tile,'tsumogiri':True}])
    delta.extend([{'type':'tsumo','actor':seat,'pai':'N'},{'type':'dahai','actor':seat,'pai':'N','tsumogiri':True},{'type':'tsumo','actor':target,'pai':'?'},{'type':'dahai','actor':target,'pai':'1m','tsumogiri':True}])
    for i,event in enumerate(delta):
        raw=bot.react(json.dumps(event),can_act=(i==len(delta)-1))
    # A state with no actionable claim may return no reaction at all.
    if raw is not None:assert json.loads(raw)['type']=='none'
    from libriichi.state import PlayerState
    state=PlayerState(seat)
    for event in events+delta:state.update(json.dumps(event))
    _,mask=state.encode_obs(4,False)
    assert not mask[43]
