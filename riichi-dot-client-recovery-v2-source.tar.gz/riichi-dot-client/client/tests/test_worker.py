import asyncio
import sys
import unittest

class WorkerTests(unittest.IsolatedAsyncioTestCase):
    async def test_cancelled_ipc_kills_and_reaps_process(self):
        from client.worker import InferenceWorker
        process=await asyncio.create_subprocess_exec(sys.executable,'-c','import sys,time; print(\'{"ready":true}\',flush=True); sys.stdin.readline(); time.sleep(60)',stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.DEVNULL)
        worker=InferenceWorker(process)
        self.assertEqual(await worker._read(),{'ready':True})
        task=asyncio.create_task(worker.act('synthetic'))
        await asyncio.sleep(.03);task.cancel()
        with self.assertRaises(asyncio.CancelledError):await task
        self.assertIsNotNone(process.returncode)
        with self.assertRaises(Exception):await worker.act('next')
    async def test_invalid_child_response_stops_process(self):
        from client.worker import InferenceWorker
        process=await asyncio.create_subprocess_exec(sys.executable,'-c','import sys,time; sys.stdin.readline(); print(\'{"error":"synthetic"}\',flush=True); time.sleep(60)',stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.DEVNULL)
        worker=InferenceWorker(process)
        with self.assertRaises(Exception):await worker.act('synthetic')
        self.assertIsNotNone(process.returncode)
