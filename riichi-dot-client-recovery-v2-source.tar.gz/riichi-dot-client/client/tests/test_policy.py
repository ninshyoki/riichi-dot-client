import json
import tempfile
import unittest
from pathlib import Path

class PolicyTests(unittest.TestCase):
    def test_checkpoint_rejects_missing_or_wrong_bytes(self):
        from client.policy import verify_checkpoint
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'wrong.pth';p.write_bytes(b'not a checkpoint')
            with self.assertRaises(Exception):verify_checkpoint(p)
            with self.assertRaises(Exception):verify_checkpoint(Path(d)/'missing.pth')
    def test_delta_replays_once_and_only_final_can_act(self):
        from client.policy import react_delta
        class Bot:
            def __init__(self):self.calls=[]
            def react(self,line,*,can_act):
                self.calls.append((json.loads(line),can_act))
                return json.dumps({'type':'none'}) if can_act else None
        bot=Bot();first=[{'type':'start_game'},{'type':'start_kyoku'},{'type':'dahai'}]
        self.assertEqual(react_delta(bot,first),{'type':'none'})
        react_delta(bot,[{'type':'end_kyoku'},{'type':'start_kyoku'},{'type':'tsumo'}])
        react_delta(bot,[{'type':'dahai'}])
        self.assertEqual(len(bot.calls),7)
        self.assertEqual([a for _,a in bot.calls],[False,False,True,False,False,True,True])
    def test_empty_delta_and_no_reaction_fail_closed(self):
        from client.policy import react_delta
        class Silent:
            def react(self,*a,**kw):return None
        for events in ([],None,[{'type':'dahai'}]):
            with self.assertRaises(Exception):react_delta(Silent(),events)
    def test_missing_assets_fail_before_importing_native_runtime(self):
        from client.policy import load_engine
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(Exception):load_engine(root=Path(d))

if __name__=='__main__':unittest.main()

class RuntimeManifestTests(unittest.TestCase):
    def make_tree(self, directory):
        import sysconfig
        root=Path(directory);(root/'client').mkdir()
        sources={f'file{i}.py':'0'*64 for i in range(436)}
        pinned={'upstream_commit':'0cff2b52982be5b1163aa9a62fb01f03ce91e0d2','sources':sources}
        native='build/python/libriichi'+sysconfig.get_config_var('EXT_SUFFIX')
        runtime={**pinned,'native':{native:'0'*64}}
        (root/'client/upstream-source-manifest.json').write_text(json.dumps(pinned))
        return root,runtime
    def test_incomplete_source_manifest_is_rejected_before_any_import(self):
        from client.policy import verify_runtime
        with tempfile.TemporaryDirectory() as d:
            root,runtime=self.make_tree(d);runtime['sources']={}
            (root/'client/runtime-manifest.json').write_text(json.dumps(runtime))
            with self.assertRaisesRegex(Exception,'source manifest'):verify_runtime(root)
    def test_absolute_parent_or_unexpected_native_paths_rejected(self):
        from client.policy import verify_runtime
        for name in ('/tmp/unsafe.so','../unsafe.so','build/python/../../unsafe.so','vendor/unsafe.so','build/python/other.so'):
            with self.subTest(name=name),tempfile.TemporaryDirectory() as d:
                root,runtime=self.make_tree(d);runtime['native']={name:'0'*64}
                (root/'client/runtime-manifest.json').write_text(json.dumps(runtime))
                with self.assertRaisesRegex(Exception,'native manifest'):verify_runtime(root)
    def test_parent_source_path_rejected_even_if_both_manifests_agree(self):
        from client.policy import verify_runtime
        with tempfile.TemporaryDirectory() as d:
            root,runtime=self.make_tree(d);runtime['sources']['../unsafe.py']=runtime['sources'].pop('file0.py')
            (root/'client/upstream-source-manifest.json').write_text(json.dumps({k:runtime[k] for k in ('upstream_commit','sources')}))
            (root/'client/runtime-manifest.json').write_text(json.dumps(runtime))
            with self.assertRaisesRegex(Exception,'source path'):verify_runtime(root)
