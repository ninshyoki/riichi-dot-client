import asyncio,json
class Worker:
    def __init__(self,*,delay=0,action=None):
        self.delay=delay;self.action={'type':'none'} if action is None else action;self.stopped=False;self.calls=[];self.seat=None
    async def start(self,seat):self.seat=seat
    async def act(self,observation):
        self.calls.append(observation)
        if self.delay:await asyncio.sleep(self.delay)
        return self.action
    async def stop(self):self.stopped=True
class Socket:
    def __init__(self,messages=(),*,send_failure=False):
        self.incoming=asyncio.Queue();self.replies=asyncio.Queue();self.closed=False;self.send_failure=send_failure
        for message in messages:self.put(message)
    def put(self,message):self.incoming.put_nowait(message if isinstance(message,(str,bytes,Exception)) else json.dumps(message))
    async def recv(self):
        value=await self.incoming.get()
        if isinstance(value,Exception):raise value
        return value
    async def send(self,reply):
        if self.send_failure:raise ConnectionError('synthetic send failure')
        self.replies.put_nowait(json.loads(reply))
    async def close(self):self.closed=True

def request(request_id=7,*,deadline=1000):
    return {'type':'request_action','request_id':request_id,'time':{'grace_ms':deadline,'bank_ms':0,'deadline_ms':deadline},'possible_actions':[{'type':'none'}],'observation':'synthetic-observation'}
