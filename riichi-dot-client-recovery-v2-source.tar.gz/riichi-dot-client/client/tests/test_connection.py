import asyncio,unittest
from client.tests.fakes import Worker,Socket,request
class ConnectionTests(unittest.IsolatedAsyncioTestCase):
    async def test_literal_reply_and_validation_receipt(self):
        from client.connection import serve_connection
        w=Worker();s=Socket([b'ignored',{'type':'unknown_future'},{'type':'start_game','id':3},request(91)])
        task=asyncio.create_task(serve_connection(s,w,validation=True))
        self.assertEqual(await asyncio.wait_for(s.replies.get(),1),{'type':'none','request_id':91})
        s.put({'type':'end_game'});s.put({'type':'validation_result','passed':True})
        self.assertEqual(await task,{'ended':True,'validation_passed':True});self.assertTrue(w.stopped and s.closed)
    async def test_negative_receipt_is_not_activation(self):
        from client.connection import serve_connection
        w=Worker();s=Socket([{'type':'start_game','id':0},{'type':'end_game'},{'type':'validation_result','passed':False}])
        self.assertFalse((await serve_connection(s,w,validation=True))['validation_passed'])
    async def test_no_postgame_receipt_is_unconfirmed(self):
        from client.connection import serve_connection
        w=Worker();s=Socket([{'type':'start_game','id':0},{'type':'end_game'},ConnectionError()])
        self.assertIsNone((await serve_connection(s,w,validation=True))['validation_passed'])
    async def test_idle_receiver_wakes_on_inference_timeout(self):
        from client.connection import serve_connection
        w=Worker(delay=60);s=Socket([{'type':'start_game','id':0},request(deadline=30)])
        with self.assertRaises(Exception):await asyncio.wait_for(serve_connection(s,w,reserve_ms=0),1)
        self.assertTrue(w.stopped and s.closed);self.assertTrue(s.replies.empty())
    async def test_external_cancel_stops_worker_and_transport(self):
        from client.connection import serve_connection
        w=Worker();s=Socket([{'type':'start_game','id':0}]);task=asyncio.create_task(serve_connection(s,w))
        await asyncio.sleep(.02);task.cancel()
        with self.assertRaises(asyncio.CancelledError):await task
        self.assertTrue(w.stopped and s.closed)
    async def test_send_failure_stops_session_without_reconnect(self):
        from client.connection import serve_connection
        w=Worker();s=Socket([{'type':'start_game','id':0},request()],send_failure=True)
        with self.assertRaises(Exception):await asyncio.wait_for(serve_connection(s,w),1)
        self.assertTrue(w.stopped and s.closed)
    async def test_receive_disconnect_stops_without_game_end(self):
        from client.connection import serve_connection
        w=Worker();s=Socket([{'type':'start_game','id':0},ConnectionError()])
        with self.assertRaises(Exception):await serve_connection(s,w)
        self.assertTrue(w.stopped and s.closed)
    async def test_invalid_receipt_does_not_claim_activation(self):
        from client.connection import serve_connection
        w=Worker();s=Socket([{'type':'start_game','id':0},{'type':'end_game'},{'type':'validation_result','passed':1}])
        with self.assertRaises(Exception):await serve_connection(s,w,validation=True)
