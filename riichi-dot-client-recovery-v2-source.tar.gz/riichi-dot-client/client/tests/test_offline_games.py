import pytest

def test_complete_all_mortal_hanchan_with_serialized_observations():
    from client.offline import run_game
    result=run_game(seed=20261016,threads=1)
    assert result['ended'] and result['illegal_actions']==0
    assert result['decisions']>100 and all(n>0 for n in result['seat_decisions'])
    assert result['event_counts'].get('end_game',0)==1

@pytest.mark.asyncio
async def test_complete_hanchan_through_four_processes_and_connection_adapter():
    from client.simulate_process import run_game
    result=await run_game(seed=20261017,threads=1,controlled_seats=(0,1,2,3))
    assert result['ended'] and result['illegal_actions']==0
    assert result['decisions']>100 and all(n>0 for n in result['seat_decisions'])
    assert all(result['workers_reaped']) and all(result['transports_closed'])
    assert result['exact_request_ids']
