"""Asynchronous lifecycle tests using a deterministic fake process boundary."""
import asyncio
import copy
import time
from unittest.mock import patch
import unittest

from client.session import Session


class FakeWorker:
    def __init__(self, *, start_gate=None, act_gate=None, start_error=None, act_error=None,
                 result=None, suppress_start_cancel=False, suppress_act_cancel=False):
        self.start_gate = start_gate
        self.act_gate = act_gate
        self.start_error = start_error
        self.act_error = act_error
        self.result = {'type': 'dahai', 'pai': '1m'} if result is None else result
        self.suppress_start_cancel = suppress_start_cancel
        self.suppress_act_cancel = suppress_act_cancel
        self.started = []
        self.observations = []
        self.start_entered = asyncio.Event()
        self.act_entered = asyncio.Event()
        self.stop_calls = 0
        self.stopped = asyncio.Event()

    async def start(self, seat):
        self.started.append(seat)
        self.start_entered.set()
        if self.start_gate:
            try:
                await self.start_gate.wait()
            except asyncio.CancelledError:
                if not self.suppress_start_cancel:
                    raise
        if self.start_error:
            raise self.start_error

    async def act(self, observation):
        self.observations.append(observation)
        self.act_entered.set()
        if self.act_gate:
            try:
                await self.act_gate.wait()
            except asyncio.CancelledError:
                if not self.suppress_act_cancel:
                    raise
        if self.act_error:
            raise self.act_error
        return copy.deepcopy(self.result)

    async def stop(self):
        self.stop_calls += 1
        self.stopped.set()


def request(request_id=0, **overrides):
    message = {'type': 'request_action', 'request_id': request_id,
               'time': {'grace_ms': 3000, 'bank_ms': 15000, 'deadline_ms': 18000},
               'possible_actions': [{'type': 'dahai', 'pai': '1m'}],
               'observation': 'b2JzZXJ2YXRpb24='}
    message.update(overrides)
    return message


class SessionTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.sessions = []
        self.sent = []

    async def asyncTearDown(self):
        for session in self.sessions:
            await session.stop()

    def make(self, worker=None, send=None, reserve_ms=250, startup_timeout=10):
        worker = worker or FakeWorker()
        async def capture(reply):
            self.sent.append(reply)
        session = Session(worker, send or capture, reserve_ms=reserve_ms, startup_timeout=startup_timeout)
        self.sessions.append(session)
        return session, worker

    async def start(self, session, seat=2):
        await session.handle({'type': 'start_game', 'id': seat})

    async def assert_closed(self, session, worker, *, error=True):
        await asyncio.wait_for(session.closed_event.wait(), 1)
        await session.stop()
        self.assertTrue(session.closed)
        self.assertFalse(session.ready)
        self.assertTrue(worker.stopped.is_set())
        if error:
            self.assertIsNotNone(session.error)

    async def test_all_four_seats_initialize_worker(self):
        for seat in range(4):
            with self.subTest(seat=seat):
                session, worker = self.make()
                await self.start(session, seat)
                self.assertEqual(worker.started, [seat])
                self.assertEqual(session.seat, seat)
                self.assertTrue(session.ready)
                self.assertFalse(session.closed)

    async def test_start_must_finish_before_ready(self):
        gate = asyncio.Event()
        session, worker = self.make(FakeWorker(start_gate=gate))
        starting = asyncio.create_task(self.start(session))
        await worker.start_entered.wait()
        self.assertFalse(session.ready)
        gate.set()
        await starting
        self.assertTrue(session.ready)

    async def test_concurrent_request_during_start_fails_closed(self):
        session, worker = self.make(FakeWorker(start_gate=asyncio.Event()))
        starting = asyncio.create_task(self.start(session))
        await worker.start_entered.wait()
        await session.handle(request())
        await asyncio.gather(starting, return_exceptions=True)
        await self.assert_closed(session, worker)
        self.assertEqual(worker.observations, [])
        self.assertEqual(self.sent, [])

    async def test_stop_during_start_prevents_late_ready(self):
        session, worker = self.make(FakeWorker(start_gate=asyncio.Event(), suppress_start_cancel=True))
        starting = asyncio.create_task(self.start(session))
        await worker.start_entered.wait()
        await session.stop()
        await asyncio.gather(starting, return_exceptions=True)
        await self.assert_closed(session, worker, error=False)
        self.assertFalse(session.ready)

    async def test_duplicate_start_fails_closed(self):
        session, worker = self.make()
        await self.start(session)
        await self.start(session)
        await self.assert_closed(session, worker)
        self.assertEqual(worker.started, [2])

    async def test_invalid_start_seat_fails_closed(self):
        for seat in [True, False, -1, 4, 2.0, '2', None]:
            with self.subTest(seat=seat):
                session, worker = self.make()
                await self.start(session, seat)
                await self.assert_closed(session, worker)
                self.assertEqual(worker.started, [])

    async def test_start_failure_fails_closed(self):
        session, worker = self.make(FakeWorker(start_error=RuntimeError('cannot start')))
        await self.start(session)
        await self.assert_closed(session, worker)

    async def test_cancelled_start_fails_closed(self):
        session, worker = self.make(FakeWorker(start_gate=asyncio.Event()))
        starting = asyncio.create_task(self.start(session))
        await worker.start_entered.wait()
        starting.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await starting
        await self.assert_closed(session, worker)

    async def test_startup_timeout_must_be_positive_finite_number(self):
        for value in [True, False, -1, 0, '1', None, float('nan'), float('inf')]:
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.make(startup_timeout=value)

    async def test_hung_start_times_out_and_stops_worker(self):
        session, worker = self.make(FakeWorker(start_gate=asyncio.Event()), startup_timeout=0.02)
        starting = asyncio.create_task(self.start(session))
        done, _ = await asyncio.wait({starting}, timeout=0.5)
        if not done:
            await session.stop()
            self.fail('startup exceeded its own timeout without stopping the worker')
        await starting
        self.assertEqual(starting.cancelling(), 0, 'internal startup cancellation must be consumed')
        await self.assert_closed(session, worker)
        self.assertIsInstance(session.error, TimeoutError)
        self.assertFalse(session.ready)
        self.assertEqual(worker.observations, [])

    async def test_start_timeout_stops_worker_even_when_start_resists_cancellation(self):
        class ResistantWorker(FakeWorker):
            async def start(self, seat):
                self.start_entered.set()
                try:
                    await asyncio.Event().wait()
                except asyncio.CancelledError:
                    await self.stopped.wait()
        session, worker = self.make(ResistantWorker(), startup_timeout=0.02)
        starting = asyncio.create_task(self.start(session))
        done, _ = await asyncio.wait({starting}, timeout=0.5)
        if not done:
            await session.stop()
            self.fail('startup exceeded its own timeout without stopping the worker')
        await starting
        self.assertEqual(starting.cancelling(), 0, 'internal startup cancellation must be consumed')
        await self.assert_closed(session, worker)
        self.assertIsInstance(session.error, TimeoutError)
        self.assertFalse(session.ready)

    async def test_cancelled_stop_does_not_cancel_process_cleanup(self):
        entered = asyncio.Event()
        release = asyncio.Event()
        class SlowStopWorker(FakeWorker):
            async def stop(self):
                self.stop_calls += 1
                entered.set()
                await release.wait()
                self.stopped.set()
        session, worker = self.make(SlowStopWorker())
        await self.start(session)
        stopping = asyncio.create_task(session.stop())
        await entered.wait()
        stopping.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await stopping
        self.assertFalse(worker.stopped.is_set())
        release.set()
        await session.stop()
        self.assertTrue(worker.stopped.is_set())
        self.assertEqual(worker.stop_calls, 1)

    async def test_external_start_cancel_waits_for_process_cleanup(self):
        entered = asyncio.Event()
        release = asyncio.Event()
        class SlowStopWorker(FakeWorker):
            async def stop(self):
                self.stop_calls += 1
                entered.set()
                await release.wait()
                self.stopped.set()
        session, worker = self.make(SlowStopWorker(start_gate=asyncio.Event()))
        starting = asyncio.create_task(self.start(session))
        await worker.start_entered.wait()
        starting.cancel()
        await entered.wait()
        self.assertFalse(starting.done())
        release.set()
        with self.assertRaises(asyncio.CancelledError):
            await starting
        await self.assert_closed(session, worker)

    async def test_action_before_start_fails_closed(self):
        session, worker = self.make()
        await session.handle(request())
        await self.assert_closed(session, worker)
        self.assertEqual(worker.observations, [])

    async def test_handle_starts_background_answer_and_returns(self):
        gate = asyncio.Event()
        session, worker = self.make(FakeWorker(act_gate=gate))
        await self.start(session)
        await asyncio.wait_for(session.handle(request()), 0.5)
        await worker.act_entered.wait()
        self.assertIsNotNone(session._task)
        self.assertEqual(self.sent, [])
        gate.set()
        await session.drain()
        self.assertEqual(self.sent, [{'type': 'dahai', 'pai': '1m', 'actor': 2, 'request_id': 0}])
        self.assertFalse(session.closed)

    async def test_observation_passes_once_without_replay(self):
        session, worker = self.make()
        await self.start(session)
        await session.handle(request(11, observation='Zmlyc3Q='))
        await session.drain()
        await session.handle(request(19, observation='c2Vjb25k'))
        await session.drain()
        self.assertEqual(worker.observations, ['Zmlyc3Q=', 'c2Vjb25k'])
        self.assertEqual([reply['request_id'] for reply in self.sent], [11, 19])

    async def test_duplicate_and_older_ids_ignore_even_malformed_payload(self):
        session, worker = self.make()
        await self.start(session)
        await session.handle(request(9))
        await session.drain()
        for value in [9, 8, 0]:
            await session.handle({'type': 'request_action', 'request_id': value, 'time': None})
        self.assertEqual(len(worker.observations), 1)
        self.assertEqual(len(self.sent), 1)
        self.assertFalse(session.closed)

    async def test_duplicate_pending_request_does_not_cancel(self):
        gate = asyncio.Event()
        session, worker = self.make(FakeWorker(act_gate=gate))
        await self.start(session)
        await session.handle(request(4))
        await worker.act_entered.wait()
        await session.handle(request(4))
        await session.handle(request(2))
        self.assertFalse(session.closed)
        gate.set()
        await session.drain()
        self.assertEqual(len(worker.observations), 1)
        self.assertEqual(len(self.sent), 1)

    async def test_newer_request_while_pending_fails_closed(self):
        session, worker = self.make(FakeWorker(act_gate=asyncio.Event()))
        await self.start(session)
        await session.handle(request(4))
        await worker.act_entered.wait()
        await session.handle(request(5))
        await self.assert_closed(session, worker)
        self.assertEqual(len(worker.observations), 1)
        self.assertEqual(self.sent, [])

    async def test_ids_require_nonnegative_exact_ints(self):
        for value in [True, False, -1, 1.0, '1', None]:
            with self.subTest(value=value):
                session, worker = self.make()
                await self.start(session)
                await session.handle(request(value))
                await self.assert_closed(session, worker)
                self.assertEqual(worker.observations, [])

    async def test_malformed_times_fail_before_inference(self):
        malformed = [None, [], {}, {'grace_ms': 1, 'bank_ms': 1}]
        for field in ['grace_ms', 'bank_ms', 'deadline_ms']:
            for wrong in [True, -1, '1', 1.5, float('nan'), float('inf'), None]:
                malformed.append({**request()['time'], field: wrong})
        for bad in malformed:
            with self.subTest(time=bad):
                session, worker = self.make()
                await self.start(session)
                await session.handle(request(time=bad))
                await self.assert_closed(session, worker)
                self.assertEqual(worker.observations, [])

    async def test_malformed_messages_fail_closed(self):
        for bad in [None, [], 'not json', {}, {'type': None}, {'type': 9}]:
            with self.subTest(message=bad):
                session, worker = self.make()
                await session.handle(bad)
                await self.assert_closed(session, worker)

    async def test_missing_or_invalid_action_payload_fails_closed(self):
        for field, wrong in [('observation', None), ('observation', 5), ('possible_actions', None),
                             ('possible_actions', {}), ('possible_actions', [])]:
            with self.subTest(field=field, value=wrong):
                session, worker = self.make()
                await self.start(session)
                await session.handle(request(**{field: wrong}))
                await session.drain()
                await self.assert_closed(session, worker)
                self.assertEqual(self.sent, [])

    async def test_unknown_information_and_raw_mjai_do_not_infer(self):
        session, worker = self.make()
        await self.start(session)
        for kind in ['hello', 'queue_status', 'start_kyoku', 'tsumo', 'dahai', 'end_kyoku', 'future_event']:
            await session.handle({'type': kind, 'unrecognized': {'request_id': 500}})
        self.assertEqual(worker.observations, [])
        self.assertEqual(self.sent, [])
        self.assertFalse(session.closed)

    async def test_deadline_expiry_stops_worker_and_wakes_receiver(self):
        session, worker = self.make(FakeWorker(act_gate=asyncio.Event()), reserve_ms=5)
        await self.start(session)
        before = asyncio.get_running_loop().time()
        await session.handle(request(time={'grace_ms': 20, 'bank_ms': 15, 'deadline_ms': 35}))
        await asyncio.wait_for(session.closed_event.wait(), 0.5)
        await session.drain()
        await self.assert_closed(session, worker)
        self.assertLess(asyncio.get_running_loop().time() - before, 0.5)
        self.assertEqual(self.sent, [])

    async def test_reserve_exhausted_never_starts_inference(self):
        session, worker = self.make(reserve_ms=250)
        await self.start(session)
        await session.handle(request(time={'grace_ms': 100, 'bank_ms': 100, 'deadline_ms': 200}))
        await session.drain()
        await self.assert_closed(session, worker)
        self.assertEqual(worker.observations, [])

    async def test_deadline_includes_send(self):
        send_entered = asyncio.Event()
        async def stalled_send(reply):
            send_entered.set()
            await asyncio.Event().wait()
        session, worker = self.make(send=stalled_send, reserve_ms=0)
        await self.start(session)
        await session.handle(request(time={'grace_ms': 10, 'bank_ms': 20, 'deadline_ms': 30}))
        await send_entered.wait()
        await asyncio.wait_for(session.closed_event.wait(), 0.5)
        await session.drain()
        await self.assert_closed(session, worker)

    async def test_deadline_counts_background_scheduling_delay(self):
        session, worker = self.make(reserve_ms=0)
        await self.start(session)
        await session.handle(request(time={'grace_ms': 10, 'bank_ms': 10, 'deadline_ms': 20}))
        time.sleep(0.03)  # Deliberately stall the event loop before the answer starts.
        await session.drain()
        await self.assert_closed(session, worker)
        self.assertEqual(worker.observations, [])
        self.assertEqual(self.sent, [])

    async def test_deadline_counts_legality_matching_before_send(self):
        from client.protocol import select_legal_reply
        def slow_selection(*args):
            time.sleep(0.03)
            return select_legal_reply(*args)
        session, worker = self.make(reserve_ms=0)
        await self.start(session)
        with patch('client.session.select_legal_reply', side_effect=slow_selection):
            await session.handle(request(time={'grace_ms': 10, 'bank_ms': 10, 'deadline_ms': 20}))
            await session.drain()
        await self.assert_closed(session, worker)
        self.assertEqual(self.sent, [])

    async def test_worker_failure_fails_closed_without_send(self):
        session, worker = self.make(FakeWorker(act_error=RuntimeError('inference failed')))
        await self.start(session)
        await session.handle(request())
        await session.drain()
        await self.assert_closed(session, worker)
        self.assertEqual(self.sent, [])

    async def test_illegal_action_fails_closed_without_send(self):
        session, worker = self.make(FakeWorker(result={'type': 'hora'}))
        await self.start(session)
        await session.handle(request())
        await session.drain()
        await self.assert_closed(session, worker)
        self.assertEqual(self.sent, [])

    async def test_send_failure_fails_closed_without_retry(self):
        attempts = []
        async def broken_send(reply):
            attempts.append(reply)
            raise OSError('socket failed')
        session, worker = self.make(send=broken_send)
        await self.start(session)
        await session.handle(request())
        await session.drain()
        await session.handle(request())
        await self.assert_closed(session, worker)
        self.assertEqual(len(attempts), 1)

    async def test_stop_invalidates_late_inference_result(self):
        session, worker = self.make(FakeWorker(act_gate=asyncio.Event(), suppress_act_cancel=True))
        await self.start(session)
        await session.handle(request())
        await worker.act_entered.wait()
        await session.stop()
        await session.drain()
        await self.assert_closed(session, worker, error=False)
        self.assertEqual(self.sent, [])

    async def test_external_drain_cancellation_invalidates_worker(self):
        session, worker = self.make(FakeWorker(act_gate=asyncio.Event()))
        await self.start(session)
        await session.handle(request())
        await worker.act_entered.wait()
        draining = asyncio.create_task(session.drain())
        await asyncio.sleep(0)
        draining.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await draining
        await self.assert_closed(session, worker)
        await session.handle(request(5))
        self.assertEqual(len(worker.observations), 1)
        self.assertEqual(self.sent, [])

    async def test_direct_action_task_cancellation_fails_closed(self):
        session, worker = self.make(FakeWorker(act_gate=asyncio.Event()))
        await self.start(session)
        await session.handle(request())
        await worker.act_entered.wait()
        session._task.cancel()
        await asyncio.gather(session._task, return_exceptions=True)
        await self.assert_closed(session, worker)

    async def test_end_game_stops_and_never_restarts(self):
        session, worker = self.make()
        await self.start(session)
        await session.handle({'type': 'end_game'})
        await self.assert_closed(session, worker, error=False)
        self.assertTrue(session.ended)
        await session.handle(request())
        await self.start(session, 3)
        self.assertEqual(worker.started, [2])
        self.assertEqual(worker.observations, [])

    async def test_stop_is_idempotent_and_drain_without_work_is_safe(self):
        session, worker = self.make()
        await session.drain()
        await session.stop()
        await session.stop()
        self.assertEqual(worker.stop_calls, 1)
        self.assertTrue(session.closed_event.is_set())

    async def test_negative_and_unknown_ack_statuses_require_manual_review(self):
        for status in ['rejected', 'unparseable', 'stale', 'defaulted', 'future_status', None]:
            with self.subTest(status=status):
                session, worker = self.make()
                await self.start(session)
                await session.handle({'type': 'action_ack', 'request_id': 0, 'status': status})
                await self.assert_closed(session, worker)
                self.assertIn('manual', str(session.error).lower())

    async def test_accepted_ack_does_not_block_next_request_or_require_latest_id(self):
        session, worker = self.make()
        await self.start(session)
        await session.handle(request(4))
        await session.drain()
        await session.handle(request(7))
        await session.drain()
        await session.handle({'type': 'action_ack', 'request_id': 4, 'status': 'accepted', 'extra': True})
        self.assertFalse(session.closed)
        self.assertEqual(len(worker.observations), 2)
        self.assertEqual(len(self.sent), 2)

    async def test_ack_id_if_present_requires_exact_nonnegative_int(self):
        for value in [True, -1, '1', 1.0, None]:
            with self.subTest(value=value):
                session, worker = self.make()
                await self.start(session)
                await session.handle({'type': 'action_ack', 'request_id': value, 'status': 'accepted'})
                await self.assert_closed(session, worker)

    async def test_stop_during_send_cancels_pending_delivery(self):
        send_entered = asyncio.Event()
        async def gated_send(reply):
            send_entered.set()
            await asyncio.Event().wait()
            self.sent.append(reply)
        session, worker = self.make(send=gated_send)
        await self.start(session)
        await session.handle(request())
        await send_entered.wait()
        await session.stop()
        await session.drain()
        self.assertEqual(self.sent, [])
        await self.assert_closed(session, worker, error=False)


if __name__ == '__main__':
    unittest.main()
