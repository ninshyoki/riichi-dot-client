"""Literal-server legality tests; no model, credentials, or network required."""
import copy
import unittest

from client.protocol import ProtocolError, select_legal_reply


class LegalReplyTests(unittest.TestCase):
    def pick(self, proposed, candidates, seat=2, request_id=17):
        return select_legal_reply(proposed, candidates, seat, request_id)

    def test_all_four_seats_are_inserted(self):
        for seat in range(4):
            with self.subTest(seat=seat):
                self.assertEqual(self.pick({'type': 'reach'}, [{'type': 'reach'}], seat),
                                 {'type': 'reach', 'actor': seat, 'request_id': 17})

    def test_none_does_not_invent_actor(self):
        self.assertEqual(self.pick({'type': 'none'}, [{'type': 'none'}]),
                         {'type': 'none', 'request_id': 17})

    def test_literal_unknown_fields_are_deep_copied(self):
        candidate = {'type': 'dahai', 'pai': '5mr', 'metadata': {'nested': [1]}, 'request_id': 8}
        before = copy.deepcopy(candidate)
        reply = self.pick({'type': 'dahai', 'pai': '5mr'}, [candidate])
        self.assertEqual(reply['request_id'], 17)
        reply['metadata']['nested'].append(2)
        self.assertEqual(candidate, before)

    def test_consumed_is_order_insensitive_and_preserves_literal_order(self):
        candidate = {'type': 'chi', 'pai': '4m', 'consumed': ['5mr', '6m']}
        self.assertEqual(self.pick({'type': 'chi', 'pai': '4m', 'consumed': ['6m', '5mr']},
                                   [candidate])['consumed'], ['5mr', '6m'])

    def test_red_five_discard_is_not_normal_five(self):
        for suit in 'mps':
            with self.subTest(suit=suit), self.assertRaises(ProtocolError):
                self.pick({'type': 'dahai', 'pai': '5' + suit},
                          [{'type': 'dahai', 'pai': '5' + suit + 'r'}])

    def test_red_five_consumed_multiset_is_not_normal_fives(self):
        with self.assertRaises(ProtocolError):
            self.pick({'type': 'pon', 'pai': '5m', 'consumed': ['5m', '5m']},
                      [{'type': 'pon', 'pai': '5m', 'consumed': ['5m', '5mr']}])

    def test_consumed_multiplicity_matters(self):
        with self.assertRaises(ProtocolError):
            self.pick({'type': 'chi', 'pai': '3m', 'consumed': ['4m', '4m']},
                      [{'type': 'chi', 'pai': '3m', 'consumed': ['4m', '5m']}])

    def test_all_action_shapes(self):
        examples = [
            {'type': 'dahai', 'pai': 'E', 'tsumogiri': False},
            {'type': 'chi', 'pai': '1s', 'consumed': ['2s', '3s']},
            {'type': 'pon', 'pai': 'P', 'consumed': ['P', 'P']},
            {'type': 'daiminkan', 'pai': 'F', 'consumed': ['F'] * 3},
            {'type': 'ankan', 'consumed': ['C'] * 4},
            {'type': 'kakan', 'pai': '5pr', 'consumed': ['5p'] * 3},
            {'type': 'reach'}, {'type': 'hora'}, {'type': 'ryukyoku'}, {'type': 'none'},
        ]
        for example in examples:
            with self.subTest(action=example['type']):
                self.assertEqual(self.pick(example, [example])['type'], example['type'])

    def test_optional_target_and_tsumogiri_are_not_invented(self):
        candidate = {'type': 'dahai', 'pai': '1m'}
        reply = self.pick({**candidate, 'target': 1, 'tsumogiri': True}, [candidate])
        self.assertNotIn('target', reply)
        self.assertNotIn('tsumogiri', reply)

    def test_candidate_optional_fields_are_preserved(self):
        candidate = {'type': 'dahai', 'pai': '1m', 'tsumogiri': False, 'target': 1}
        self.assertEqual(self.pick({'type': 'dahai', 'pai': '1m'}, [candidate])['tsumogiri'], False)

    def test_explicit_optional_mismatches_are_rejected(self):
        for field, a, b in [('target', 0, 1), ('tsumogiri', True, False), ('pai', 'E', 'S')]:
            with self.subTest(field=field), self.assertRaises(ProtocolError):
                self.pick({'type': 'hora', field: a}, [{'type': 'hora', field: b}])

    def test_hora_optional_pai_can_be_omitted(self):
        self.assertNotIn('pai', self.pick({'type': 'hora', 'pai': 'E', 'target': 0}, [{'type': 'hora'}]))

    def test_identical_candidates_deduplicate(self):
        candidate = {'type': 'pon', 'pai': 'E', 'consumed': ['E', 'E']}
        self.assertEqual(self.pick(candidate, [candidate, copy.deepcopy(candidate)])['type'], 'pon')

    def test_distinct_semantic_matches_are_ambiguous(self):
        for candidates in [[{'type': 'reach'}, {'type': 'reach', 'tag': 1}],
                           [{'type': 'reach', 'tag': True}, {'type': 'reach', 'tag': 1}],
                           [{'type': 'reach'}, {'type': 'reach', 'actor': 2}]]:
            with self.subTest(candidates=candidates), self.assertRaises(ProtocolError):
                self.pick({'type': 'reach'}, candidates)

    def test_no_match_does_not_choose_win_or_fallback(self):
        with self.assertRaises(ProtocolError):
            self.pick({'type': 'none'}, [{'type': 'hora'}, {'type': 'dahai', 'pai': '1m'}])

    def test_empty_candidates_are_rejected(self):
        with self.assertRaises(ProtocolError):
            self.pick({'type': 'none'}, [])

    def test_seat_and_request_id_require_exact_ints(self):
        for seat in [True, False, -1, 4, '0', 0.0, None]:
            with self.subTest(seat=seat), self.assertRaises(ProtocolError):
                self.pick({'type': 'none'}, [{'type': 'none'}], seat=seat)
        for request_id in [True, False, -1, '1', 1.0, None]:
            with self.subTest(request_id=request_id), self.assertRaises(ProtocolError):
                self.pick({'type': 'none'}, [{'type': 'none'}], request_id=request_id)

    def test_zero_request_id_is_preserved(self):
        self.assertEqual(self.pick({'type': 'none'}, [{'type': 'none'}], request_id=0)['request_id'], 0)

    def test_wrong_actor_is_rejected_on_either_side(self):
        for wrong in [0, 1, 3, True, -1, 4, 2.0, '2', None]:
            for proposal_side in [True, False]:
                good = {'type': 'reach'}
                bad = {**good, 'actor': wrong}
                with self.subTest(actor=wrong, proposal_side=proposal_side), self.assertRaises(ProtocolError):
                    self.pick(bad if proposal_side else good, [good if proposal_side else bad])

    def test_targets_require_exact_seat_ints(self):
        for wrong in [True, -1, 4, 1.0, '1', None]:
            for proposal_side in [True, False]:
                good = {'type': 'hora'}
                bad = {**good, 'target': wrong}
                with self.subTest(target=wrong, proposal_side=proposal_side), self.assertRaises(ProtocolError):
                    self.pick(bad if proposal_side else good, [good if proposal_side else bad])

    def test_tsumogiri_requires_exact_bool(self):
        for wrong in [0, 1, 'true', None]:
            for proposal_side in [True, False]:
                good = {'type': 'dahai', 'pai': '1m'}
                bad = {**good, 'tsumogiri': wrong}
                with self.subTest(tsumogiri=wrong, proposal_side=proposal_side), self.assertRaises(ProtocolError):
                    self.pick(bad if proposal_side else good, [good if proposal_side else bad])

    def test_required_tiles_are_validated(self):
        for action in ['dahai', 'chi', 'pon', 'daiminkan', 'kakan']:
            consumed = {'chi': 2, 'pon': 2, 'daiminkan': 3, 'kakan': 3}.get(action)
            for bad_pai in [None, '0m', '10m', '4mr', 'X', True]:
                bad = {'type': action, 'pai': bad_pai}
                if consumed:
                    bad['consumed'] = ['1m'] * consumed
                with self.subTest(action=action, pai=bad_pai), self.assertRaises(ProtocolError):
                    self.pick(bad, [bad])
            bad.pop('pai')
            with self.subTest(action=action, missing=True), self.assertRaises(ProtocolError):
                self.pick(bad, [bad])

    def test_consumed_cardinality_and_tiles_are_validated(self):
        for action, length in [('chi', 2), ('pon', 2), ('daiminkan', 3), ('kakan', 3), ('ankan', 4)]:
            good = {'type': action, 'pai': '1m', 'consumed': ['1m'] * length}
            for wrong in [None, '1m', ['1m'] * (length - 1), ['1m'] * (length + 1), ['X'] * length]:
                bad = {**good, 'consumed': wrong}
                with self.subTest(action=action, consumed=wrong), self.assertRaises(ProtocolError):
                    self.pick(bad, [bad])
            bad.pop('consumed')
            with self.subTest(action=action, missing=True), self.assertRaises(ProtocolError):
                self.pick(bad, [bad])

    def test_unknown_and_malformed_actions_are_rejected(self):
        for bad in [None, [], {}, {'type': 'automatic_win'}, {'type': 1}]:
            with self.subTest(bad=bad), self.assertRaises(ProtocolError):
                self.pick(bad, [{'type': 'none'}])
            with self.subTest(candidate=bad), self.assertRaises(ProtocolError):
                self.pick({'type': 'none'}, [bad])
        for bad in [None, {}, (), 'none']:
            with self.subTest(candidates=bad), self.assertRaises(ProtocolError):
                self.pick({'type': 'none'}, bad)


if __name__ == '__main__':
    unittest.main()
