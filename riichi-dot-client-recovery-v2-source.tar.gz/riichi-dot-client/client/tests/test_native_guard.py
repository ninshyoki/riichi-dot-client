"""Actual original Bot guard across all seats, using its source regression fixture."""
import json,re
import numpy as np
import pytest
from client.policy import ROOT,load_engine,react_delta
@pytest.fixture(scope='module',autouse=True)
def runtime():return load_engine(threads=1)
class PreferWinEngine:
    engine_type='mortal';name='guard-fixture-only';is_oracle=False;version=4;enable_quick_eval=False
    def __init__(self,guard):self.enable_rule_based_agari_guard=guard
    def react_batch(self,obs,masks,invisible_obs):
        m=np.asarray(masks);q=np.where(m,0.0,-np.inf);q[:,43]=np.where(m[:,43],100.0,-np.inf)
        return q.argmax(-1).tolist(),q.tolist(),m.tolist(),[True]*len(m)
def fixture_events(seat,*,scores=False,dora=False):
    source=(ROOT/'vendor/Mortal-upstream/libriichi/src/state/test.rs').read_text()
    section=source.split('fn rule_based_agari_all_last_minogashi() {',1)[1]
    log=re.search(r'let log = r#"(.*?)"#;',section,re.S).group(1)
    events=[json.loads(line) for line in log.strip().splitlines()]
    if scores:events[0]['scores']=[30000,10000,30000,30000]
    if dora:events.insert(-1,{'type':'dora','dora_marker':'5m'})
    shift=(seat-1)%4
    for event in events:
        for key in ('actor','target','oya'):
            if key in event:event[key]=(event[key]+shift)%4
        for key in ('scores','tehais'):
            if key in event:
                before=event[key];event[key]=[before[(i-shift)%4] for i in range(4)]
    return [{'type':'start_game'}]+events
@pytest.mark.parametrize('seat',range(4))
@pytest.mark.parametrize('guard,scores,dora,win',[(True,False,False,False),(False,False,False,True),(True,True,False,True),(True,False,True,True)])
def test_actual_original_guard_changes_native_bot(seat,guard,scores,dora,win):
    from libriichi.mjai import Bot
    from libriichi.state import PlayerState
    events=fixture_events(seat,scores=scores,dora=dora)
    result=react_delta(Bot(PreferWinEngine(guard),seat),events)
    assert (result['type']=='hora')==win and result.get('actor')==seat
    state=PlayerState(seat)
    for event in events:state.update(json.dumps(event))
    state.validate_reaction(json.dumps(result))
