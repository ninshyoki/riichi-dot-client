# SPDX-License-Identifier: AGPL-3.0-or-later
"""User-operated hidden-terminal submission for exactly one validation game."""
from __future__ import annotations
import asyncio,getpass,logging,os,ssl,sys,termios,warnings
from websockets.asyncio.client import connect as WebSocketConnect
from .worker import InferenceWorker
from .connection import serve_connection
ENDPOINT='wss://game.riichi.dev/ws/validate'
PROMPT='Paste bot token (hidden). Enter submits it to riichi.dev for ONE validation game; empty Enter cancels: '
class NoRedirectConnect(WebSocketConnect):
    def process_redirect(self,exc):return exc
connect=NoRedirectConnect

def require_tty():
    if not sys.stdin.isatty() or not sys.stdout.isatty():raise RuntimeError('An interactive private terminal is required')
    fd=os.open('/dev/tty',os.O_RDWR|os.O_NOCTTY)
    try:
        if not os.isatty(fd):raise RuntimeError('No controlling terminal')
        termios.tcgetattr(fd)
    finally:os.close(fd)

def read_token():
    require_tty()
    with warnings.catch_warnings():
        warnings.simplefilter('error',getpass.GetPassWarning);token=getpass.getpass(prompt=PROMPT)
    if not token:return None
    if len(token)>16384 or any(ord(c)<33 or ord(c)>126 for c in token):raise RuntimeError('Invalid token input')
    return token

def make_ssl_context():
    # Do not consume inherited SSLKEYLOGFILE.
    context=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT);context.check_hostname=True;context.verify_mode=ssl.CERT_REQUIRED
    context.load_default_certs(ssl.Purpose.SERVER_AUTH);context.keylog_filename=None
    return context

async def run():
    worker=None;token=None;headers=None
    try:
        print('Verifying original Mortal-S42 and warming one CPU inference worker...',flush=True)
        worker=await InferenceWorker.create(threads=1)
        print('Ready. This submits your pending bot to one validation game at riichi.dev.\nIt will stop after the game. Keep this terminal open; Ctrl-C cancels.',flush=True)
        token=read_token()
        if token is None:print('Cancelled before connecting.',flush=True);return 2
        logger=logging.Logger('private_validation_transport');logger.disabled=True;logger.propagate=False
        headers={'Authorization':'Bearer '+token};token=None
        async with connect(ENDPOINT,additional_headers=headers,ssl=make_ssl_context(),proxy=None,logger=logger,compression=None,open_timeout=15,close_timeout=5,max_size=4*1024*1024,max_queue=32) as ws:
            print('Connected. Playing the validation game...',flush=True)
            result=await serve_connection(ws,worker,validation=True)
        passed=result.get('validation_passed')
        if passed is True:
            print('Validation passed. The server confirmed activation. Stopped after one game.',flush=True);return 0
        if passed is False:
            print('Validation did not pass. Stopped; check the bot page before another attempt.',flush=True);return 1
        print('Game ended, but no validation receipt was received. Activation is unconfirmed; check the bot page.',flush=True);return 1
    except asyncio.CancelledError:raise
    except Exception:
        print('Validation stopped safely. No retry was started. Check the bot page before another attempt.',flush=True);return 1
    finally:
        token=None
        if headers is not None:headers.clear()
        if worker is not None:await worker.stop()

def main():
    if len(sys.argv)!=1:
        print('No arguments are accepted. Use a private interactive terminal. Do not put a token on the command line.',file=sys.stderr);return 2
    try:return asyncio.run(run())
    except KeyboardInterrupt:
        print('\nStopped. No retry was started.',flush=True);return 130
if __name__=='__main__':raise SystemExit(main())
