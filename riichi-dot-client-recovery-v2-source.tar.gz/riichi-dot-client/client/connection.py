# SPDX-License-Identifier: AGPL-3.0-or-later
"""Already-connected WebSocket adapter; never reconnects or queues games."""
from __future__ import annotations
import asyncio,json
from websockets.exceptions import ConnectionClosed
from .protocol import ProtocolError
from .session import Session
async def serve_connection(ws,worker,*,reserve_ms=250,validation=False,receipt_timeout=30):
    async def send(reply):await ws.send(json.dumps(reply,allow_nan=False,separators=(',',':')))
    async def finish():
        if not validation:return {'ended':True}
        try:
            async with asyncio.timeout(receipt_timeout):
                while True:
                    raw=await ws.recv()
                    if isinstance(raw,bytes):continue
                    message=json.loads(raw)
                    if isinstance(message,dict) and message.get('type')=='validation_result':
                        if type(message.get('passed')) is not bool:raise ProtocolError('Invalid validation receipt')
                        return {'ended':True,'validation_passed':message['passed']}
        except (TimeoutError,ConnectionError,ConnectionClosed):return {'ended':True,'validation_passed':None}
    session=Session(worker,send,reserve_ms=reserve_ms);receiver=None
    stopped=asyncio.create_task(session.closed_event.wait())
    try:
        while not session.closed:
            receiver=asyncio.create_task(ws.recv())
            done,_=await asyncio.wait((receiver,stopped),return_when=asyncio.FIRST_COMPLETED)
            if stopped in done:
                if session.error:raise session.error
                if session.ended:return await finish()
                raise ProtocolError('Session stopped without game-end evidence')
            try:raw=receiver.result()
            except Exception:raise ProtocolError('Disconnected before game end; do not requeue') from None
            if isinstance(raw,bytes):continue
            if not isinstance(raw,str) or len(raw)>4*1024*1024:raise ProtocolError('Invalid or oversized wire message')
            try:message=json.loads(raw,parse_constant=lambda _:(_ for _ in ()).throw(ValueError()))
            except (ValueError,TypeError):raise ProtocolError('Invalid JSON wire message') from None
            await session.handle(message)
        if session.error:raise session.error
        if session.ended:return await finish()
        raise ProtocolError('Stopped before game end; do not requeue')
    finally:
        for task in (receiver,stopped):
            if task is not None and not task.done():task.cancel()
        await session.stop()
        await asyncio.gather(*(t for t in (receiver,stopped) if t is not None),return_exceptions=True)
        try:await asyncio.wait_for(ws.close(),5)
        except Exception:pass
